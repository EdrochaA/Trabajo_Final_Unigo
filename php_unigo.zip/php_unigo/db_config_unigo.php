<?php
// db_config_unigo.php

define('DB_HOST', 'localhost');
define('DB_USER', 'Xerocha002');
define('DB_PASS', '9vhITEcTE');
define('DB_NAME', 'Xerocha002_unigo');

// Crear conexión
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Comprobar conexión
if ($conn->connect_error) {
    // Respondemos JSON de error si no hay conexión
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'message' => 'Error de conexión a la base de datos: ' . $conn->connect_error
    ]);
    exit;
}
?>